# Pharmacy Management System
Installation Steps(Configuration)
1. Download and Unzip file on your local system.
2. Put Pharmacy-Management-System folder inside root directory

Database Configuration

Open phpmyadmin
Create Database pms
Import database pms.sql

Login and Password Details of Pharmacy-Management-System

Login Details for admin : 
      Username: admin
      Password: admin

Login Details for pharmacist :
      Username: abhi
      password: abhi

Login Details for manager :
      Username: vinay
      password: vinay
      
Login Details for cashier :
      Username: abc
      password: abc
